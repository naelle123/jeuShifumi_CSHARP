﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace jeuShifumi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random rnd = new Random();
        int a, move,tour,score;
        int win;

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            tour++;
            timer1.Enabled = true;
            lblManches.Text = tour.ToString();
            //if (timer1.Enabled==false)
            //{
                if (rdbFeuille.Checked == true && ptbChoix.Image == Properties.Resources.game0)
                {
                    win = 0;

                }
                else if (rdbPierre.Checked == true && ptbChoix.Image == Properties.Resources.game1)
                {
                    win = 0;
                }
                else if (rdbciseau.Checked == true && ptbChoix.Image == Properties.Resources.game2)
                {
                    win = 0;
                }
                else if (rdbciseau.Checked == true && ptbChoix.Image == Properties.Resources.game0)
                {
                    win = 1;
                    score++;
                }
                else if (rdbFeuille.Checked == true && ptbChoix.Image == Properties.Resources.game1)
                {
                    win = 1;
                    score++;
                }
                else if (rdbPierre.Checked == true && ptbChoix.Image == Properties.Resources.game2)
                {
                    win = 1;
                    score++;
                }
                else if (rdbciseau.Checked == true && ptbChoix.Image == Properties.Resources.game1)
                {
                    win = -1;
                }
                else if (rdbFeuille.Checked == true && ptbChoix.Image == Properties.Resources.game2)
                {
                    win = -1;
                }
                else if (rdbPierre.Checked == true && ptbChoix.Image == Properties.Resources.game0)
                {
                    win = -1;
                }

                if (win == 1 && tour == 1)
                {
                    etoile1.Image = Properties.Resources.star_win;
                }
                else if (win == 0 && tour == 1)
                {
                    etoile1.Image = Properties.Resources.star_equality;
                }
                else if (win == -1 && tour == 1)
                {
                    etoile1.Image = Properties.Resources.star_losse;
                }

                if (win == 1 && tour == 2)
                {
                    etoile2.Image = Properties.Resources.star_win;
                }
                else if (win == 0 && tour == 2)
                {
                    etoile2.Image = Properties.Resources.star_equality;
                }
                else if (win == -1 && tour == 2)
                {
                    etoile2.Image = Properties.Resources.star_losse;
                }

                if (win == 1 && tour == 3)
                {
                    etoile3.Image = Properties.Resources.star_win;
                }
                else if (win == 0 && tour == 3)
                {
                    etoile3.Image = Properties.Resources.star_equality;
                }
                else if (win == -1 && tour == 3)
                {
                    etoile3.Image = Properties.Resources.star_losse;
                }
                lblScore.Text = score.ToString();
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            move++;
             if (move < 20)
            {
                a = rnd.Next(9);
                switch (a)
                {
                    case 1:
                        ptbChoix.Image = Properties.Resources.game0;
                        break;
                    case 2:
                        ptbChoix.Image = Properties.Resources.game1;
                        break;
                    case 3:
                        ptbChoix.Image = Properties.Resources.game2;
                        break;
                }
            }
            else
            {
                timer1.Enabled = false;
                move = 0;

            }
        }
    }
}
